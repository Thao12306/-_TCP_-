﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

//TXT需引入
using System.IO;

namespace socket_client
{
    public partial class Login : Form
    {
        //TXT计算实例
        txt_opt_list TXT_OPT = new txt_opt_list();

        //登录信息汇总到form1
        //一定的是 static 类型
        public static byte FORM_LOGIN_TO_FORM1 = 0;

        string[] temp_str_array_ref = new string[100];

        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            for (int i = 1; i <= 99; i++)
            {
                temp_str_array_ref[i - 1] = i.ToString();
            }

            Init_Control_View();
            Init_NO_Control_View();
        }

        /*######################################################################初始化#####################################################*/

        //控件初始化
        public void Init_Control_View()
        {
            //提示
            textBox1.ReadOnly = true;
            textBox3.ReadOnly = true;
            this.textBox2.Select();
            textBox2.Text = string_from_textbox_to_empty(textBox2);
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //非控件功能初始化
        public void Init_NO_Control_View()
        {
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        /*######################################################################窗体控件###################################################*/

        //登录
        private void button1_Click(object sender, EventArgs e)
        {
            xxxX();
        }

        public void xxxX()
        {
            byte temp = 0;
            string temp_str = " ";
            string[] temp_str_array = new string[128];
            bool temp_bool = false;
            byte temp_len = 0;

            if (textBox2.Text != string.Empty)
            {
                try
                {
                    temp_str = textBox2.Text.Trim();
                    temp = Convert.ToByte(temp_str, 10);
                    if ((temp > 0) && (temp <= 99))
                    {
                        temp_len = (byte)TXT_OPT.XXX_TXT_LINES(temp_str_array, "C:\\Users\\J2\\Desktop\\新项目_TCP_多个客户端相互通信\\Client_Log.txt");
                        temp_bool = Compare_StrArray_Str(temp_str_array, temp_str, temp_len);
                        if (temp_bool == true)//重名
                        {
                            MessageBox.Show("用户名重复，请检查!用户名范围 1 -> 99，详情请点击'已用用户名查询'", "用户名重复提示");
                        }
                        else//可以通过
                        {
                            FORM_LOGIN_TO_FORM1 = temp;//跨界传输
                            TXT_OPT.Writer_TXT_DATA(temp_str, "C:\\Users\\J2\\Desktop\\新项目_TCP_多个客户端相互通信\\Client_Log.txt");

                            //打开后续界面
                            this.Hide();
                            Form1 Form1 = new Form1();
                            Form1.Show();
                        }
                    }
                    else
                    {
                        MessageBox.Show("用户名超限，请检查!用户名范围 1 -> 99", "用户名错误提示");
                    }
                }
                catch
                {

                }
            }
            else
            {
                MessageBox.Show("用户名为空，请检查!用户名范围 1 -> 99", "用户名为空提示");
            }
        }

        public bool Compare_StrArray_Str(string[] strarray_in, string str_compare,int len)
        {
            bool temp_bool = false;

            for (int i = 0; i < len; i++)
            {
                if (strarray_in[i] == str_compare)//找到了
                {
                    temp_bool = true;
                    break;
                }
                else
                {
                }
            }
            return temp_bool;
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //已用用户名查询
        private void button4_Click(object sender, EventArgs e)
        {
            string[] temp_str_array = new string[100];
            int temp_len = 0;

            temp_len = TXT_OPT.XXX_TXT_LINES(temp_str_array, "C:\\Users\\J2\\Desktop\\新项目_TCP_多个客户端相互通信\\Client_Log.txt");

            string[] arr3 = temp_str_array_ref.Except(temp_str_array).ToArray();

            //清除可选项
            //避免重复出现
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();

            for (int i = 0; i < temp_len; i++)
            {
                comboBox1.Items.Add(temp_str_array[i]);
            }

            for (int j = 0; j < arr3.Length; j++)
            {
                comboBox2.Items.Add(arr3[j]);
            }
            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;

            textBox1.Text = temp_len.ToString();
            textBox3.Text = arr3.Length.ToString();
        }

        //实现鼠标点击复制
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox2.Text = comboBox2.Text;
        }

        //限制用户名只能输入 0-9 19:25 2018/10/27
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0' && e.KeyChar <= '9') || (e.KeyChar == 8))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //退出
        private void button2_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        /*######################################################################其它自定义#################################################*/

        //修改textbox内容判断为空的bug 21:16 2018/10/25
        //自动去空
        //针对textbox控件
        public string string_from_textbox_to_empty(TextBox textbox_in)
        {
            string temp_string = " ";

            temp_string = textbox_in.Text.Trim();

            if (temp_string.Contains(" "))
            {
                temp_string = temp_string.Replace(" ", "");
            }

            return temp_string;
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/
        /*###################################################################自己写的类##################################################*/

        /*************************************************************************************************************.TXT文本文档*/
        //TXT需引入
        //using System.IO;
        public class txt_opt_list
        {
            //构造函数
            public txt_opt_list()
            {

            }

            //bug解决 20:57 2018/10/27
            public int XXX_TXT_LINES(string[] fileLines,string path)
            {
                int temp_len = 0;
                string lines = " ";

                try
                {
                    if (!System.IO.File.Exists(path))//如何不存在文件路径
                    {
                        MessageBox.Show("文件不存在或是路径错误，请检查!", "文件错误提示");
                    }
                    else
                    {
                        using (StreamReader sr = new StreamReader(path))
                        {
                            while ((lines = sr.ReadLine()) != null)
                            {
                                fileLines[temp_len++] = lines;
                            }
                        }
                    }
                }
                catch
                { }
                return temp_len;
            }

            public int Get_TXT_LINES(string path)
            { 
                int temp_len = 0;

                try
                {
                    if (!System.IO.File.Exists(path))//如何不存在文件路径
                    {
                        MessageBox.Show("文件不存在或是路径错误，请检查!", "文件错误提示");
                    }
                }
                catch
                { }

                try
                {
                    using(StreamReader sr = new StreamReader(path))
                    {
                        string lines = " ";
                        while((lines = sr.ReadLine()) != null)
                        {
                            temp_len++;
                        }
                    }
                }
                catch
                {
                
                }

                return temp_len;
            }

            //读取TXT数据
            public string[] Read_TXT_DATA(string path)
            {
                try
                {
                    if (!System.IO.File.Exists(path))//如何不存在文件路径
                    {
                        MessageBox.Show("文件不存在或是路径错误，请检查!", "文件错误提示");
                    }
                }
                catch
                { }

                //读出内容
                String[] fileLines = System.IO.File.ReadAllLines(path);

                return fileLines;
            }

            //删除TXT某一行数据
            public void Remove_Singline_TXT_DATA(int index, string path)
            {
                try
                {
                    if (!System.IO.File.Exists(path))//如何不存在文件路径
                    {
                        MessageBox.Show("文件不存在或是路径错误，请检查!", "文件错误提示");
                    }
                }
                catch
                { }

                var strs = System.IO.File.ReadAllLines(path, Encoding.Default).ToList();

                strs.RemoveAt(index);//删除

                System.IO.File.WriteAllLines(path, strs, Encoding.Default);
            }

            //写入TXT数据
            public void Writer_TXT_DATA(string str_in, string path)
            {
                try
                {
                    if (!System.IO.File.Exists(path))
                    {
                        FileStream stream = System.IO.File.Create(path);
                        stream.Close();
                        stream.Dispose();
                    }

                    //写入数据
                    using (StreamWriter writer = new StreamWriter(path, true))
                    {
                        writer.WriteLine(str_in);
                    }

                    long size = 0;

                    //获取文件大小
                    using (FileStream file = System.IO.File.OpenRead(path))
                    {
                        size = file.Length;//文件大小。byte
                    }

                    //判断大于2M，自动删除。
                    if (size > 1024)
                    {
                        System.IO.File.Delete(path);
                    }
                }
                catch
                {

                }
            }
        }
        /*******************************************************************************结束******************************.TXT文本文档*/
    }
}
