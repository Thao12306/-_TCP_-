﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

//socket

using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Net.NetworkInformation;

namespace socket_slave
{
    public partial class Form1 : Form
    {
        //连接按键状态改变标志
        byte TCP_LINK_STATE_CNT = 0;

        //TCP连接成功标志
        byte TCP_CONN_SUCCESS_FLAG = 0;

        //发送或是接收信息清除标志
        byte CLEAR_TX_FLAG = 0;
        byte CLEAR_RX_FLAG = 0;

        //tcp发送、接收次数计数
        int TCP_TX_CNT = 0;
        int TCP_RX_CNT = 0;

        //发送按键标记
        byte SEND_BUTTON_FLAG = 0;

        //TCP接收成功标记
        byte TCP_REC_SUCCESS_FLAG = 0;

        //客户端上线计数
        byte CLIENT_ON_LINE_CNT = 0;

        //
        Socket Tcp_Socket_Listen = null;
        Socket Tcp_Socket_Send = null; 

        //保存已经保存的客户端线程
        private List<Thread> client_conn_thread_list;
        private List<Socket> client_conn_socket_list;

        //方法封装
        Action<TextBox, string> Show_TextBox_Message;


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Init_Control_View();
            Init_NO_Control_View();
        }

        /*######################################################################窗体控件###################################################*/

        //连接
        private void button1_Click(object sender, EventArgs e)
        {
            TCP_LINK_STATE_CNT++;
            if ((TCP_LINK_STATE_CNT % 2) != 0)
            {
                Create_Tcp_Socket(comboBox1, textBox9);
            }
            else
            {
                TCP_LINK_STATE_CNT = 0;
                Close_Tcp_Socket();
            }
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //发送
        private void button2_Click(object sender, EventArgs e)
        {
            byte[] temp = new byte[10];

            temp[0] = 3;
            temp[1] = 4;

            client_conn_socket_list[0].Send(temp, 2, SocketFlags.None);
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //清除发送信息
        private void button4_Click(object sender, EventArgs e)
        {

        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //清除接收信息
        private void button3_Click(object sender, EventArgs e)
        {

        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //关于软件
        private void button5_Click(object sender, EventArgs e)
        {

        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //定时器 定时扫描按键状态
        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        /*######################################################################初始化#####################################################*/

        //控件初始化
        public void Init_Control_View()
        {
            //所有显示控件都清空
            textBox3.Text = " ";
            textBox2.Text = " ";

            textBox9.Text = " ";
            textBox1.Text = " ";

            textBox4.Text = " ";
            textBox5.Text = " ";

            textBox7.Text = " ";
            textBox8.Text = " ";

            textBox10.Text = " ";
            textBox11.Text = " ";

            //所以只做显示使用的控件 配置成只读功能
            textBox3.ReadOnly = true;
            textBox2.ReadOnly = true;
            textBox1.ReadOnly = true;

            textBox4.ReadOnly = true;
            textBox5.ReadOnly = true;

            textBox7.ReadOnly = true;
            textBox8.ReadOnly = true;

            textBox10.ReadOnly = true;
            textBox11.ReadOnly = true;

            //Port、发送缓冲区自动去空
            //解决textbox控件一开始光标指向第二个空格的bug 13:34 2018/10/26
            textBox9.Text = string_from_textbox_to_empty(textBox9);
            textBox2.Text = string_from_textbox_to_empty(textBox2);

            //光标定点
            this.textBox9.Select();

            //按键处理
            button1.BackColor = Color.Green;//连接按键
            //button2.Enabled = false;//发送失能
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //非控件功能初始化
        public void Init_NO_Control_View()
        {
            //获取IP地址
            string[] get_ipaddr = get_local_addr();

            for (int i = 0; i < get_ipaddr.Length; i++)
            {
                comboBox1.Items.Add(get_ipaddr[i]);//添加到列表
            }

            //默认第一个IP地址
            comboBox1.SelectedIndex = 0;

            //在子线程中更新界面元素
            Show_TextBox_Message = delegate(TextBox show_textbox, string str_in)
            {
                Show_String(show_textbox, str_in);
            };

            //关闭跨线程检测
            Control.CheckForIllegalCrossThreadCalls = false;
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        /*######################################################################其它自定义#################################################*/

        //修改textbox内容判断为空的bug 21:16 2018/10/25
        //自动去空
        //针对textbox控件
        public string string_from_textbox_to_empty(TextBox textbox_in)
        {
            string temp_string = " ";

            temp_string = textbox_in.Text.Trim();

            if (temp_string.Contains(" "))
            {
                temp_string = temp_string.Replace(" ", "");
            }

            return temp_string;
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //智能提醒
        //针对textbox控件 button控件
        public void show_send_smart_reminder(string string_in, Button button_show)
        {
            if (string_in == string.Empty)
            {
                button_show.Enabled = false;
                button_show.Text = "请输入要发送的内容 ";
                button_show.BackColor = Color.Goldenrod;
            }
            else
            {
                button_show.Enabled = true;
                button_show.Text = "可以发送数据";
                button_show.BackColor = Color.GreenYellow;
            }
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        /*######################################################################TCP相关程序################################################*/

        //检测端口是否被占用
        //暂时没有用
        public static bool PortInUse(int port)
        {
            bool inUse = false;

            IPGlobalProperties ipProperties = IPGlobalProperties.GetIPGlobalProperties();

            IPEndPoint[] ipEndPoints = ipProperties.GetActiveTcpListeners();

            foreach (IPEndPoint endPoint in ipEndPoints)
            {
                if (endPoint.Port == port)
                {
                    inUse = true;
                    break;
                }
            }
            return inUse;
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //获取本地IP4/IP6地址
        private string[] get_local_addr()
        {
            string host_mame = " ";

            //获取主机名
            host_mame = Dns.GetHostName();

            //获取主机地址信息
            IPHostEntry ipHostEntry = Dns.GetHostEntry(host_mame);

            string[] get_ipaddr = new string[ipHostEntry.AddressList.Length];
            int i = 0;

            foreach (IPAddress ip_addr in ipHostEntry.AddressList)
            {
                get_ipaddr[i] = ip_addr.ToString();
                i++;
            }
            return get_ipaddr;
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //关闭TCP连接
        public void Close_Tcp_Socket()
        {
            Tcp_Socket_Listen.Close();

            if (Tcp_Socket_Send.Connected)//解决正在侦听 突然关闭服务器的bug 16:22 2018/10/15 
            {
                Tcp_Socket_Send.Close();
            }
            else
            { }  

            //客户端无法再次连接
            //关闭线程
            for (int i = 0; i < client_conn_thread_list.Count; i++)
            {
                client_conn_thread_list[i].Abort();
            }

            textBox1.Invoke(Show_TextBox_Message, textBox1, "断开连接");
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        public void Create_Tcp_Socket(ComboBox ip_combox, TextBox port_textbox)
        {
            int port_name = 0;

            if ((ip_combox.SelectedItem.ToString() != string.Empty) && (port_textbox.Text != string.Empty))//填写IP地址 端口号 
            {
                try
                {      
                    //清空链表
                    client_conn_thread_list = new List<Thread>();
                    client_conn_socket_list = new List<Socket>();

                    port_name = Convert.ToInt32(port_textbox.Text);

                    //监听本机ip
                    IPAddress ip = IPAddress.Any;
                    IPEndPoint point = new IPEndPoint(ip, port_name);

                    //IPV4
                    Tcp_Socket_Listen = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    Tcp_Socket_Listen.Bind(point);
                    Tcp_Socket_Listen.Listen(0);

                    Thread Tcp_Socket_Listen_thread = new Thread(Tcp_Listen_Deal);

                    client_conn_thread_list.Add(Tcp_Socket_Listen_thread);//添加到列表

                    Tcp_Socket_Listen_thread.IsBackground = true;
                    Tcp_Socket_Listen_thread.Start(Tcp_Socket_Listen);
                }
                catch
                {
                
                }              
            }
            else
            {
                MessageBox.Show("请填写正确的IP地址以及端口号!!!", "连接错误提示");
            }
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        void Tcp_Listen_Deal(object o)
        {
            Socket socketWatch = o as Socket;

            while (true)
            {
                try
                {
                    Tcp_Socket_Send = socketWatch.Accept();

                    client_conn_socket_list.Add(Tcp_Socket_Send);

                    textBox1.Invoke(Show_TextBox_Message, textBox1, "与客户端连接成功!");

                    Thread Tcp_Socket_Rec_thread = new Thread(Tcp_Socket_Rec_Deal);

                    client_conn_thread_list.Add(Tcp_Socket_Rec_thread);//添加到列表

                    Tcp_Socket_Rec_thread.IsBackground = true;
                    Tcp_Socket_Rec_thread.Start(Tcp_Socket_Send);
                }
                catch
                {

                    Close_Tcp_Socket();
                    break;
                }             
            }
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        void Tcp_Socket_Rec_Deal(object o)
        {
            int temp_len = 0;

            byte[] get_data = new byte[1024];
            string[] temp_str = new string[1024];

            Socket Tcp_Socket_Send = o as Socket;

            while (true)
            {
                try
                {
                    if (Tcp_Socket_Send.Connected)
                    {
                        temp_len = Tcp_Socket_Send.Receive(get_data);

                        if (temp_len == 0)//无数据
                        {
                            break;
                        }
                        else
                        {
                            Show_Byte_To_String(get_data, temp_str, temp_len, textBox3);                         
                        }
                    }
                    else
                    {
                        Close_Tcp_Socket();
                        break;
                    }
                }
                catch
                {
                    Close_Tcp_Socket();
                    break;
                }
            }
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        /*#####################################################################暂未用到程序###############################################*/

        //获取当前时间
        public static string GetTimeStamp()
        {
            TimeSpan ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
            return Convert.ToInt64(ts.TotalSeconds).ToString();
        }

        public static DateTime GetTime(string timeStamp)
        {
            DateTime dtStart = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));

            long lTime = long.Parse(timeStamp + "0000000");
            TimeSpan toNow = new TimeSpan(lTime);
            return dtStart.Add(toNow);
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //字节数组转换成字符串数组并显示
        public void Show_Byte_To_String(byte[] byte_in, string[] str_out, int len_in, TextBox show_textbox)
        {
            if (byte_in.Length > 0)
            {
                //添加换行
                show_textbox.AppendText("\r\n");//解决第一行不对齐的 bug(暂时方式 找不到更合适的) 

                for (int i = 0; i < len_in; i++)
                {
                    //转换为大写十六进制字符串
                    str_out[i] = Convert.ToString(byte_in[i], 16).ToUpper();

                    //字符串显示
                    show_textbox.AppendText((str_out[i].Length == 1 ? ("0" + str_out[i]) : str_out[i]) + " ");
                }
            }
            else
            { }
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //字符串数组转换成字节数组并显示
        public void Tcp_Send_String_To_Byte(string str_in, Socket tcp_socket)
        {
            if (str_in.Length > 0)
            {
                byte[] byte_out = new byte[str_in.Length];

                byte_out = System.Text.Encoding.UTF8.GetBytes(str_in);

                tcp_socket.Send(byte_out, 0, byte_out.Length, SocketFlags.None);
            }
            else
            {
            }
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //发送字符串
        private void Tcp_Send_String_to_byte(string str_in, Socket tcp_socket)
        {
            int i = 0;
            int num_of_page = 0;
            int num_of_singe = 0;

            if (str_in.Length > 0)
            {
                try
                {
                    byte[] Send_Buff = new byte[str_in.Length];

                    num_of_page = str_in.Length / 2; //两个一组数据发送
                    num_of_singe = str_in.Length - (num_of_page * 2);//只剩下一个数据

                    if ((num_of_page == 0) && (num_of_singe > 0))//只发送一个数据
                    {
                        Send_Buff[0] = Convert.ToByte(str_in.Substring(0, 1), 16);

                        tcp_socket.Send(Send_Buff, 0, 1, SocketFlags.None);
                    }
                    else if ((num_of_page > 0) && (num_of_singe == 0))
                    {
                        for (i = 0; i < num_of_page; i++)//两个一组数据发送
                        {
                            Send_Buff[i] = Convert.ToByte(str_in.Substring(2 * i, 2), 16);
                        }
                        tcp_socket.Send(Send_Buff, 0, num_of_page, SocketFlags.None);
                    }
                    else
                    {
                        for (i = 0; i < num_of_page; i++)
                        {
                            Send_Buff[i] = Convert.ToByte(str_in.Substring(2 * i, 2), 16);
                        }

                        //余下的数据
                        Send_Buff[i++] = Convert.ToByte(str_in.Substring((2 * num_of_page), 1), 16);

                        tcp_socket.Send(Send_Buff, 0, num_of_page + num_of_singe, SocketFlags.None);
                    }
                }
                catch
                {
                }
            }
            else
            {    
                MessageBox.Show("请填写要发送的信息再点击发送!", "发送失败提示!");//修复无发送内容点击发送无提示 bug
            }
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //显示字符串
        public void Show_String(TextBox show_textbox, string str_in)
        {
            //if ("".Equals(show_textbox.Text))
            //{
            show_textbox.Text = str_in;
            //}
            //else
            //{
            //    show_textbox.Text += str_in;
            //}
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //数据比较 用于主动断开连接
        public byte Data_Compare(byte[] data_check, byte[] data_in)
        {
            int j = 0;
            for (int i = 0; i < data_check.Length; i++)
            {
                if (data_check[i] == data_in[j])
                {
                    j++;
                }
                else
                {
                    return 2;
                }
            }
            return 1;
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        /*##################################################################无用程序######################################################*/

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
    }
}
