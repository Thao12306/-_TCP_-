﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

//socket
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Net.NetworkInformation;

//textbox 正则表达式
using System.Text.RegularExpressions;

/*------------------------------------------------------------------分隔符-------------------------------------------------------*/

/*######################################################################窗体控件###################################################*/

/*######################################################################实现 窗体控件##############################################*/

/*######################################################################初始化#####################################################*/

/*######################################################################其它自定义#################################################*/

/*######################################################################无用窗体控件###############################################*/

namespace socket_client
{
    public partial class Form1 : Form
    {

        //全局变量***********************************************************************************

        //客户端socket
        Socket client_socket = null;

        //保存已经保存的客户端线程
        private List<Thread> client_conn_thread_list;

        //方法封装
        Action<TextBox,string> Show_TextBox_Message;

        //创建一个定时器
        //定时接收socket服务器传来的信息
        System.Timers.Timer Tcp_Socket_Rec_Timer = new System.Timers.Timer();

        //委托调用 serial接收使用
        delegate void TCP_Rec_Data_Deal();
        TCP_Rec_Data_Deal Dele_TCP_Rec_Deal;

        //帧命令解析
        Rec_Frame_List Frame_List = new Rec_Frame_List(256);

        //循环队列实例
        loop_queue_list<byte> queue = new loop_queue_list<byte>(256);

        //CRC计算实例
        cal_check_list cal_crc = new cal_check_list();

        //各种标志位 ***********************************************************************************

        //连接按键状态改变标志
        byte TCP_LINK_STATE_CNT = 0;

        //TCP连接失败次数统计标志
        byte TCP_CONN_FAILED_CNT = 0;

        //连接按键按下标记
        byte TCP_CONN_BUTTON_DOWN_FLAG = 0;

        //发送或是接收信息清除标志
        byte CLEAR_TX_FLAG = 0;
        byte CLEAR_RX_FLAG = 0;

        //tcp发送、接收次数计数
        int TCP_TX_CNT = 0;
        int TCP_RX_CNT = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Init_Control_View();
            Init_NO_Control_View();
        }

        /*######################################################################窗体控件###################################################*/

        //连接
        private void button2_Click(object sender, EventArgs e)
        {
            bool temp_check_socketconn = false;//socket状态判断
            byte show_openclose_message_flag = 0;//状态显示

            TCP_LINK_STATE_CNT++;
            if (TCP_LINK_STATE_CNT % 2 != 0)//第一次开启连接
            {
                Create_Tcp_Socket(comboBox1, textBox2);
                temp_check_socketconn = Socket_isConnected(client_socket);
                if (temp_check_socketconn == true)
                {
                    show_openclose_message_flag = 1;//连接成功
                }
                else
                {
                    TCP_LINK_STATE_CNT = 0;
                    show_openclose_message_flag = 2;//连接失败
                }

            }
            else//第二次关闭连接
            {
                TCP_LINK_STATE_CNT = 0;
                Close_Tcp_Socket();

                show_openclose_message_flag = 3;//关闭连接
            }

            //状态提示
            show_message_for_OpenClose_Tcp_Socket(show_openclose_message_flag);
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //发送
        private void button1_Click(object sender, EventArgs e)
        {
            //数据帧(不带数据校验)
            //数据转义
            //发送数据
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //清除发送信息
        private void button3_Click(object sender, EventArgs e)
        {
            CLEAR_TX_FLAG++;
            if (CLEAR_TX_FLAG % 2 != 0)
            {
                if (textBox4.Text != " ")//存在数据
                {
                    textBox4.Text = " ";
                    button3.Text = "T已清零";
                }
                else//没有任何数据
                {
                }
            }
            else//第一次按下
            {
                if (textBox4.Text == " ")//不存在数据
                {
                    //信息提示
                    button3.Text = "T已清零";
                }
                else
                {
                }
                CLEAR_TX_FLAG = 0;
            }
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //清除接收信息
        private void button4_Click(object sender, EventArgs e)
        {
            CLEAR_RX_FLAG++;
            if (CLEAR_RX_FLAG % 2 != 0)
            {
                if (textBox3.Text != " ")//存在数据
                {
                    textBox3.Text = " ";
                    button4.Text = "R已清零";
                }
                else//没有任何数据
                {
                }
            }
            else//第一次按下
            {
                if (textBox3.Text == " ")//不存在数据
                {
                    //信息提示
                    button4.Text = "R已清零";
                }
                else
                {
                }
                CLEAR_RX_FLAG = 0;
            }
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //发送缓冲区填写数据
        //智能提醒
        /*
         * 解决使用 private void textBox4_TextChanged(object sender, EventArgs e)
         * 控件无法自动根据有无内容进行自动判断的bug
         * 13:23 2018/10/26
         * 错误的操作如下
         * //if (textBox4.Text == string.Empty)
            {
                button1.Text = "请输入要发送的内容 ";
                button1.BackColor = Color.Goldenrod;
            }
            else
            {
                button1.Text = "可以发送数据";
                button1.BackColor = Color.GreenYellow;
            }
         * 
         * 正确的操作
         * 
           // string str_in = " ";

            str_in = textBox4.Text.Trim(); //自动去空

            if (str_in.Contains(" "))
            {
                str_in = str_in.Replace(" ", "");
            }
            if (str_in == string.Empty)
            {
                button1.Text = "请输入要发送的内容 ";
                button1.BackColor = Color.Goldenrod;
            }
            else
            {
                button1.Text = "可以发送数据";
                button1.BackColor = Color.GreenYellow;
            }
         */
        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            string temp_string = " ";

            if (TCP_CONN_BUTTON_DOWN_FLAG == 1)
            {
                temp_string = string_from_textbox_to_empty(textBox4);
                show_send_smart_reminder(temp_string, button1);
            }
            else
            { }
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //定时器 定时扫描按键状态
        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //限制port只能输入 0-9 16:24 2018/10/26
        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0' && e.KeyChar <= '9') || (e.KeyChar == 8))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //限制port输入数据范围 0-65535
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            //先判断位数
            //再判断范围 出错 暂时没有办法处理 16:54 2018/10/26

            string temp_string = " ";

            temp_string = textBox2.Text.Trim();

            if ((temp_string.Length >= 0) && (temp_string.Length <= 5))//正确范围
            {
                //未完待续...
            }
            else
            {
                MessageBox.Show("端口号位数过多，请检查!", "端口号位数错误提示");
            }
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //关于软件
        private void button5_Click(object sender, EventArgs e)
        {

        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        /*######################################################################初始化#####################################################*/

        //控件初始化
        public void Init_Control_View()
        {
            //所有显示控件都清空
            textBox3.Text = " ";
            textBox4.Text = " ";

            textBox2.Text = " ";
            textBox6.Text = " ";

            textBox7.Text = " ";
            textBox8.Text = " ";

            textBox9.Text = " ";
            textBox5.Text = " ";

            textBox1.Text = " ";
            textBox10.Text = " ";

            //所以只做显示使用的控件 配置成只读功能
            textBox3.ReadOnly = true;
            textBox4.ReadOnly = true;
            textBox6.ReadOnly = true;

            textBox7.ReadOnly = true;
            textBox8.ReadOnly = true;

            textBox9.ReadOnly = true;
            textBox5.ReadOnly = true;

            textBox1.ReadOnly = true;
            textBox10.ReadOnly = true;

            //Port、发送缓冲区自动去空
            //解决textbox控件一开始光标指向第二个空格的bug 13:34 2018/10/26
            textBox2.Text = string_from_textbox_to_empty(textBox2);
            textBox4.Text = string_from_textbox_to_empty(textBox4);

            //光标定点
            this.textBox2.Select();

            //按键处理
            button2.BackColor = Color.Green;//连接按键
            button1.Enabled = false;//发送失能
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //非控件功能初始化
        public void Init_NO_Control_View()
        {
            //获取IP地址
            string[] get_ipaddr = get_local_addr();

            for (int i = 0; i < get_ipaddr.Length; i++)
            {
                comboBox1.Items.Add(get_ipaddr[i]);//添加到列表
            }

            //默认第一个IP地址
            comboBox1.SelectedIndex = 0;

            //在子线程中更新界面元素
            Show_TextBox_Message = delegate(TextBox show_textbox, string str_in)
            {
                Show_String(show_textbox, str_in);
            };

            //委托实例化
            //否则无法使用委托 TCP接收使用
            Dele_TCP_Rec_Deal = new TCP_Rec_Data_Deal(MyDele_TCP_Rec_Deal);

            //关闭跨线程检测
            Control.CheckForIllegalCrossThreadCalls = false;
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        /*######################################################################TCP相关程序################################################*/

        //检测TCP是否连接
        public bool Socket_isConnected(Socket conn_socket)
        {
            bool temp = false;

            if (conn_socket.Connected)
            {
                temp = true;
            }
            else
            {
                temp = false;
            }
            return temp;
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //检测端口是否被占用
        //暂未用到
        public static bool PortInUse(int port)
        {
            bool inUse = false;

            IPGlobalProperties ipProperties = IPGlobalProperties.GetIPGlobalProperties();

            IPEndPoint[] ipEndPoints = ipProperties.GetActiveTcpListeners();

            foreach (IPEndPoint endPoint in ipEndPoints)
            {
                if (endPoint.Port == port)
                {
                    inUse = true;
                    break;
                }
            }
            return inUse;
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //获取本地IP4/IP6地址
        private string[] get_local_addr()
        {
            string host_mame = " ";

            //获取主机名
            host_mame = Dns.GetHostName();

            //获取主机地址信息
            IPHostEntry ipHostEntry = Dns.GetHostEntry(host_mame);

            string[] get_ipaddr = new string[ipHostEntry.AddressList.Length];
            int i = 0;

            foreach (IPAddress ip_addr in ipHostEntry.AddressList)
            {
                get_ipaddr[i] = ip_addr.ToString();
                i++;
            }

            return get_ipaddr;
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //关闭TCP连接
        public void Close_Tcp_Socket()
        {
            /*
             解决客户端断开socket 第二次无法连接的bug 16:01 2018/10/26
             * 错误的做法如下
             * //关闭定时器（TCP接收数据使用）
                Tcp_Socket_Rec_Timer.Enabled = false;
                client_socket.Close();
                //关闭线程
                for (int i = 0; i < client_conn_thread_list.Count; i++)
                {
                    client_conn_thread_list[i].Abort();
                }
             * 正确的做法如下
             */
            if (client_socket == null)
            {
                return;
            }

            if (!client_socket.Connected)
            {
                return;
            }

            try
            {
                client_socket.Shutdown(SocketShutdown.Both);
            }
            catch
            { }

            try
            {
                client_socket.Close();
            }
            catch
            { }

            //关闭定时器（TCP接收数据使用）
            Tcp_Socket_Rec_Timer.Enabled = false;

            //关闭线程
            for (int i = 0; i < client_conn_thread_list.Count; i++)
            {
                client_conn_thread_list[i].Abort();
            }
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //创建TCP
        public void Create_Tcp_Socket(ComboBox ip_combox, TextBox port_textbox)
        {
            string str_ip_addr = " ";
            int port_name = 0;
            byte show_message_flag = 0;//状态显示

            //修改textbox内容判断为空的bug 21:16 2018/10/25
            //错误的写法
            //if ((ip_combox.SelectedItem.ToString() != " ") && (port_textbox.Text != " "))//填写IP地址 端口号 
            //正确的写法
            if ((ip_combox.SelectedItem.ToString() != string.Empty) && (port_textbox.Text != string.Empty))//填写IP地址 端口号 
            {
                try
                {
                    //获取IP地址
                    str_ip_addr = ip_combox.SelectedItem.ToString();
                    port_name = Convert.ToInt32(port_textbox.Text.Trim());//数据类型一定是 int 否则会出错

                    //创建IP4 TCP 流
                    client_socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    IPAddress ip = IPAddress.Parse(str_ip_addr);
                    IPEndPoint point = new IPEndPoint(ip, port_name);

                    //尝试连接
                    try
                    {
                        client_socket.Connect(point);
                        show_message_flag = 1;//正在连接                  
                    }
                    catch
                    {
                        Close_Tcp_Socket();//关闭socket
                    }
                }
                catch
                {
                    show_message_flag = 5;//IP、port出错或是未填                           
                }

                //判断是否已经连接上
                try
                {
                    if (client_socket.Connected == true)
                    {
                        show_message_flag = 2;//已连接
                    }
                    else
                    {
                        show_message_flag = 3;//未连接
                    }
                }
                catch
                {
                    show_message_flag = 4;//连接出错
                }
            }
            else
            {
                show_message_flag = 6;//port未填                
            }

            //状态显示
            show_message_for_Create_Tcp_Socket(show_message_flag);
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        /*######################################################################其它自定义#################################################*/

        //修改textbox内容判断为空的bug 21:16 2018/10/25
        //自动去空
        //针对textbox控件
        public string string_from_textbox_to_empty(TextBox textbox_in)
        {
            string temp_string = " ";

            temp_string = textbox_in.Text.Trim();

            if (temp_string.Contains(" "))
            {
                temp_string = temp_string.Replace(" ", "");
            }

            return temp_string;
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //智能提醒
        //针对textbox控件 button控件
        public void show_send_smart_reminder(string string_in, Button button_show)
        {
            if (string_in == string.Empty)
            {
                button_show.Enabled = false;
                button_show.Text = "请输入要发送的内容 ";
                button_show.BackColor = Color.Goldenrod;
            }
            else
            {
                button_show.Enabled = true;
                button_show.Text = "可以发送数据";
                button_show.BackColor = Color.GreenYellow;
            }
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        public void Tcp_Send_bytes(byte[] data_in, int data_len, Socket send_socket)
        {
            if (data_len > 0)//存在数据
            {
                if (send_socket.Connected)//已经连接
                {
                    try
                    {
                        send_socket.Send(data_in, 0, data_len, SocketFlags.None);
                    }
                    catch
                    { }
                }
                else
                { }
            }
            else
            { }
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //发送格式帧制定
        public int Send_Message_Frame(byte[] local_name, byte link_flag, byte talk_lag, byte[] data_in, byte[] data_out)
        {
            int index = 0;
            byte local_name_index = 0;
            byte data_in_index = 0;
            byte[] temp_data = new byte[256];

            //开头
            temp_data[index++] = (byte)':';

            //添加本机用户信息
            //格式 Uxx
            temp_data[index++] = local_name[local_name_index++];
            temp_data[index++] = local_name[local_name_index++];
            temp_data[index++] = local_name[local_name_index++];

            //上下线 聊天
            //In/Out/Talk
            //0,1,2
            switch (link_flag)
            {
                case 0:
                    {
                        temp_data[index++] = (byte)'I';
                        break;
                    }
                case 1:
                    {
                        temp_data[index++] = (byte)'O';
                        break;
                    }
                case 2:
                    {
                        temp_data[index++] = (byte)'T';
                        break;
                    }
                //其它分支 在这里填写...
                default: break;
            }

            //聊天类型 单对单 单对多
            //0,1,
            switch (talk_lag)
            {
                case 0:
                    {
                        temp_data[index++] = (byte)0X00;
                        break;
                    }
                case 1:
                    {
                        temp_data[index++] = (byte)0X01;
                        break;
                    }
                //其它分支 在这里填写...
                default: break;
            }

            //内容 包含 另一个客户端的信息 Uxx
            //具体看 talk_lag
            for (int i = 0; i < data_in.Length; i++)
            {
                temp_data[index++] = data_in[data_in_index++]; ;
            }

            //结尾
            temp_data[index++] = (byte)'\r';
            temp_data[index++] = (byte)'\n';

            //数据拷贝
            Buffer.BlockCopy(temp_data, 0, data_out, 0, index);

            return index;
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        /*######################################################################显示信息相关##############################################*/
       
        //显示TCP连接的的具体情况
        public void show_message_for_OpenClose_Tcp_Socket(byte flag_in)
        {
            switch (flag_in)
            {
                case 0: break;
                case 1:
                    {
                        flag_in = 0;

                        /*
                        解决客户端断开socket 第二次无法连接的bug 16:01 2018/10/26
                         * 只有在创建完成socket之后才创建接收线程
                        */

                        //清空链表
                        client_conn_thread_list = new List<Thread>();

                        //开始定时
                        Tcp_Socket_Rec_Timer.Enabled = true;

                        //开启线程
                        Thread Tcp_Socket_Rec_Timer_thread = new Thread(Tcp_Socket_Rec_TimerMange);

                        //线程保存
                        client_conn_thread_list.Add(Tcp_Socket_Rec_Timer_thread);

                        //线程开启
                        Tcp_Socket_Rec_Timer_thread.Start();

                        //光标定点
                        this.textBox4.Select();

                        TCP_CONN_BUTTON_DOWN_FLAG = 1;//连接按键按下标记 用于智能提醒

                        //IP、Port不可操作
                        comboBox1.Enabled = false;
                        textBox2.Enabled = false;

                        button1.Enabled = false;
                        button1.Text = "请输入要发送的内容 ";
                        button1.BackColor = Color.Goldenrod;

                        //可填写发送内容
                        textBox4.ReadOnly = false;

                        //连接按键状态改变
                        button2.Text = "断开连接";
                        button2.BackColor = Color.Red;

                        break;
                    }
                case 2:
                    {
                        flag_in = 0;

                        //光标定点
                        this.textBox2.Select();

                        TCP_CONN_BUTTON_DOWN_FLAG = 0;//连接按键按下标记 用于智能提醒

                        TCP_CONN_FAILED_CNT++;//连接失败次数记忆

                        //IP、Port不可操作
                        comboBox1.Enabled = true;
                        textBox2.Enabled = true;

                        //发送按键可操作
                        button1.Enabled = false;
                        button1.Text = "不可操作";
                        button1.BackColor = Color.Gray;

                        //可填写发送内容
                        textBox4.ReadOnly = true;

                        //连接按键状态改变
                        button2.Text = "连接";
                        button2.BackColor = Color.Green;

                        if (TCP_CONN_FAILED_CNT == 3)//连接失败超3次 弹出错误提示
                        {
                            TCP_CONN_FAILED_CNT = 0;
                            MessageBox.Show("连接服务器失败次数超限，请检查客户端及服务器的IP地址、端口号", "连接错误提示");
                        }

                        break;
                    }
                case 3:
                    {
                        flag_in = 0;

                        //光标定点
                        this.textBox2.Select();

                        TCP_CONN_BUTTON_DOWN_FLAG = 0;//连接按键按下标记 用于智能提醒

                        //IP、Port不可操作
                        comboBox1.Enabled = true;
                        textBox2.Enabled = true;

                        //发送按键可操作
                        button1.Enabled = false;
                        button1.Text = "不可操作";
                        button1.BackColor = Color.Gray;

                        //可填写发送内容
                        textBox4.ReadOnly = true;

                        //连接按键状态改变
                        button2.Text = "连接";
                        button2.BackColor = Color.Green;

                        textBox6.Invoke(Show_TextBox_Message, textBox6, "主动与服务器断开连接!");

                        break;
                    } 
                //其它分支 在这里填写...
                default: break;
            }
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //显示TCP连接的的具体情况
        public void show_message_for_Create_Tcp_Socket(byte flag_in)
        {
            switch (flag_in)
            {
                case 0: break;
                case 1:
                    {
                        flag_in = 0;
                        textBox6.Invoke(Show_TextBox_Message, textBox6, "客户连接中...");
                        break;
                    }
                case 2:
                    {
                        flag_in = 0;
                        textBox6.Invoke(Show_TextBox_Message, textBox6, "与服务器连接成功");
                        Tcp_Socket_Rec_Timer.Enabled = true;//定时器开始工作(TCP接收)
                        break;
                    }
                case 3:
                    {
                        flag_in = 0;
                        textBox6.Invoke(Show_TextBox_Message, textBox6, "与服务器连接失败");
                        Tcp_Socket_Rec_Timer.Enabled = false;//定时器停止工作(TCP接收)
                        break;
                    }
                case 4:
                    {
                        flag_in = 0;
                        textBox6.Invoke(Show_TextBox_Message, textBox6, "检测连接状态出错");
                        break;
                    }
                case 5:
                    {
                        flag_in = 0;
                        MessageBox.Show("IP地址、端口号错误，请检查!", "连接错误提示");
                        break;
                    }
                case 6:
                    {
                        flag_in = 0;
                        MessageBox.Show("端口号错误，请填写正确端口号!", "信息缺失错误提示");
                        break;
                    }
                //其它分支 在这里填写...
                default: break;
            }
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        /*####################################################################TCP接收数据相关处理#########################################*/

        //定时器事件
        void Tcp_Socket_Rec_TimerMange()
        {
            Tcp_Socket_Rec_Timer.Elapsed += new ElapsedEventHandler(Tcp_Recive_Deal);//定时事件的方法    
            Tcp_Socket_Rec_Timer.Interval = 100; 
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //tcp接收程序 线程
        void Tcp_Recive_Deal(object sender, EventArgs e)
        {
            int temp_len = 0;
            int index = 0;
            int unescape_len = 0;

            byte[] get_data = new byte[256];
            byte[] unescape_data = new byte[256];
            string[] temp_str = new string[256];

            //一直接收数据
            while (true)
            {
                try
                {
                    if (client_socket.Connected)//已经连接
                    {
                        //读取数据
                        while(client_socket.Available >0)
                        {
                            temp_len += client_socket.Receive(get_data, index, client_socket.ReceiveBufferSize, SocketFlags.None);
                            index += temp_len;
                        }

                        if (temp_len > 0)//有数据 可以在这里处理
                        {
                            //数据转义
                            //数据入队
                            //委托处理
                            //清空接收数据
                            //清空接收数据长度
                            unescape_len = Frame_List.Div_Data_UnEscape(get_data, unescape_data, temp_len);
                            queue.Insert_Queue(unescape_data, unescape_len);
                            this.Invoke(Dele_TCP_Rec_Deal, null);
                            Array.Clear(get_data, 0, temp_len);
                            temp_len = 0;

                            //暂时显示
                            Show_Byte_To_String(get_data, temp_str, temp_len,textBox3);
                        }
                        else//无数据 退出
                        {
                            break;
                        }
                    }
                    else//未连接
                    {
                        Close_Tcp_Socket();//关闭tcp连接 退出
                        break;
                    }
                }
                catch
                {
                    Close_Tcp_Socket();//关闭tcp连接 退出
                    break;
                }              
            }
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //委托事件 TCP使用
        public void MyDele_TCP_Rec_Deal()
        {
            TCP_Deal_RecFrame_Data_TWO();
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //接收数据帧解析
        public bool TCP_Deal_RecFrame_Data_ONE()
        {
            int temp_len = 0;
            byte temp_data = 0;
            byte[] get_data = new byte[256];

            //进来先清空之前的缓冲区
            //避免数组越界
            Frame_List.Clear_Fream();

            //获取数据帧
            temp_len = queue.get_lenth();
            if (temp_len > 0)
            {
                //获取数据
                queue.Delete_Queue(get_data, temp_len);

                for (int i = 0; i < temp_len; i++)
                {
                    temp_data = get_data[i];//获取一个数据

                    if (Frame_List.frame_header_flag < Frame_List.head[0])
                    {
                        Frame_List.Find_Frame_Header(temp_data);
                    }
                    else
                    {
                        //容易出错
                        Frame_List.frame_rbuff[Frame_List.frame_len++] = temp_data;

                        if (Frame_List.Find_Frame_tail() == 0)
                        {
                            if ((Frame_List.min_len == 0) || (Frame_List.min_len > 0) && (Frame_List.frame_len > Frame_List.min_len))
                            {
                                return true;
                            }
                            else
                            {
                                Frame_List.Clear_Fream();
                            }
                        }
                        if (Frame_List.frame_len > Frame_List.frame_size)
                        {
                            Frame_List.Clear_Fream();
                        }
                    }
                }
            }
            else
            {
                ;
            }
            return false;
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //接收数据帧解析 -> 深度解析
        public void TCP_Deal_RecFrame_Data_TWO()
        {
            int temp_len = 0;
            byte[] temp_data = new byte[256];

            if (TCP_Deal_RecFrame_Data_ONE() == true)//解析数据正确
            {
                Buffer.BlockCopy(Frame_List.frame_rbuff, 0, temp_data, 0, Frame_List.frame_len);//数据拷贝

                //获取数据
                temp_len = Frame_List.frame_len;

                //数据解析...
            }
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        /*#####################################################################暂未用到程序###############################################*/

        //获取当前时间
        public static string GetTimeStamp()
        {
            TimeSpan ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
            return Convert.ToInt64(ts.TotalSeconds).ToString();
        }

        public static DateTime GetTime(string timeStamp)
        {
            DateTime dtStart = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));

            long lTime = long.Parse(timeStamp + "0000000");
            TimeSpan toNow = new TimeSpan(lTime);
            return dtStart.Add(toNow);
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //字节数组转换成字符串数组并显示
        public void Show_Byte_To_String(byte[] byte_in, string[] str_out, int len_in, TextBox show_textbox)
        {
            if (byte_in.Length > 0)
            {
                //添加换行
                show_textbox.AppendText("\r\n");//解决第一行不对齐的 bug(暂时方式 找不到更合适的) 

                for (int i = 0; i < len_in; i++)
                {
                    //转换为大写十六进制字符串
                    str_out[i] = Convert.ToString(byte_in[i], 16).ToUpper();

                    //字符串显示
                    show_textbox.AppendText((str_out[i].Length == 1 ? ("0" + str_out[i]) : str_out[i]) + " ");
                }
            }
            else
            { }
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //字符串数组转换成字节数组并显示
        public void Tcp_Send_String_To_Byte(string str_in, Socket tcp_socket)
        {
            if (str_in.Length > 0)
            {
                byte[] byte_out = new byte[str_in.Length];

                byte_out = System.Text.Encoding.UTF8.GetBytes(str_in);

                tcp_socket.Send(byte_out, 0, byte_out.Length, SocketFlags.None);
            }
            else
            {
            }
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //发送字符串
        private void Tcp_Send_String_to_byte(string str_in, Socket tcp_socket)
        {
            int i = 0;
            int num_of_page = 0;
            int num_of_singe = 0;

            if (str_in.Length > 0)
            {
                try
                {
                    byte[] Send_Buff = new byte[str_in.Length];

                    num_of_page = str_in.Length / 2; //两个一组数据发送
                    num_of_singe = str_in.Length - (num_of_page * 2);//只剩下一个数据

                    if ((num_of_page == 0) && (num_of_singe > 0))//只发送一个数据
                    {
                        Send_Buff[0] = Convert.ToByte(str_in.Substring(0, 1), 16);

                        tcp_socket.Send(Send_Buff, 0, 1, SocketFlags.None);
                    }
                    else if ((num_of_page > 0) && (num_of_singe == 0))
                    {
                        for (i = 0; i < num_of_page; i++)//两个一组数据发送
                        {
                            Send_Buff[i] = Convert.ToByte(str_in.Substring(2 * i, 2), 16);
                        }
                        tcp_socket.Send(Send_Buff, 0, num_of_page, SocketFlags.None);
                    }
                    else
                    {
                        for (i = 0; i < num_of_page; i++)
                        {
                            Send_Buff[i] = Convert.ToByte(str_in.Substring(2 * i, 2), 16);
                        }

                        //余下的数据
                        Send_Buff[i++] = Convert.ToByte(str_in.Substring((2 * num_of_page), 1), 16);

                        tcp_socket.Send(Send_Buff, 0, num_of_page + num_of_singe, SocketFlags.None);
                    }
                }
                catch
                {
                }
            }
            else
            {
                MessageBox.Show("请填写要发送的信息再点击发送!", "发送失败提示!");//修复无发送内容点击发送无提示 bug
            }
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //显示字符串
        public void Show_String(TextBox show_textbox, string str_in)
        {
            //if ("".Equals(show_textbox.Text))
            //{
                show_textbox.Text = str_in;
            //}
            //else
            //{
            //    show_textbox.Text += str_in;
            //}
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        //数据比较 用于主动断开连接
        public byte Data_Compare(byte[] data_check, byte[] data_in)
        {
            int j = 0;
            for (int i = 0; i < data_check.Length; i++)
            {
                if (data_check[i] == data_in[j])
                {
                    j++;
                }
                else
                {
                    return 2;
                }
            }
            return 1;
        }

        /*------------------------------------------------------------------分隔符-------------------------------------------------------*/

        /*###################################################################自己写的类##################################################*/

        /*************************************************************************************************************LOOP_QUEUE*/
        public class loop_queue_list<T>
        {
            public int LOOP_QUEUE_SIZE_MAX;     //数组容量最大值
            public int head_pointer;            //头指针
            public int tail_pointer;            //尾指针
            public T[] array;                   //数组

            //构造函数
            public loop_queue_list(int size)
            {
                this.LOOP_QUEUE_SIZE_MAX = size;
                this.head_pointer = 0;
                this.tail_pointer = 0;
                this.array = new T[size];
            }

            public bool Insert_Queue(T value)
            {
                if ((tail_pointer + 1) % LOOP_QUEUE_SIZE_MAX == head_pointer)//满了
                {
                    return false;
                }
                else
                {
                    array[tail_pointer] = value;
                    tail_pointer = (tail_pointer + 1) % LOOP_QUEUE_SIZE_MAX;
                    return true;
                }
            }

            public void Insert_Queue(T[] pdat, int len)
            {
                for (int i = 0; i < len; i++)
                {
                    if ((tail_pointer + 1) % LOOP_QUEUE_SIZE_MAX == head_pointer)//满了
                    {
                        return;
                    }
                    else
                    {
                        array[tail_pointer] = pdat[i];
                        tail_pointer = (tail_pointer + 1) % LOOP_QUEUE_SIZE_MAX;
                    }
                }
            }

            public T Delete_Queue()
            {
                T value = default(T);

                if (tail_pointer == head_pointer)//空了
                {
                    return value;
                }
                else
                {
                    value = array[head_pointer];
                    head_pointer = (head_pointer + 1) % LOOP_QUEUE_SIZE_MAX;
                    return value;
                }
            }

            public void Delete_Queue(T[] pdat, int len)
            {
                for (int i = 0; i < len; i++)
                {
                    if (tail_pointer == head_pointer)//空了
                    {
                        return;
                    }
                    else
                    {
                        pdat[i] = array[head_pointer];
                        head_pointer = (head_pointer + 1) % LOOP_QUEUE_SIZE_MAX;
                    }
                }
            }

            public int get_lenth()
            {
                return ((tail_pointer + LOOP_QUEUE_SIZE_MAX - head_pointer) % LOOP_QUEUE_SIZE_MAX);
            }
        }

        /**********************************************************************************************结束*************LOOP_QUEUE */

        /***********************************************************************************************************************MATH*/

        public class Rec_Frame_List
        {
            public byte[] head;                           //帧头
            public byte[] tail;                           //帧尾
            public byte min_len;                          //最小帧长度

            public byte frame_header_flag;                //帧头标志
            public byte[] frame_rbuff;                    //帧缓冲区
            public int frame_size;                        //帧缓冲区大小
            public int frame_len;                         //帧缓冲区长度

            //构造函数
            public Rec_Frame_List(int size)
            {
                this.head = new byte[3] { 0x01, 0x3A, 0X00 };//可替换帧头帧尾 
                this.tail = new byte[3] { 0x02, 0x0D, 0X0A };
                this.min_len = 7;
                this.frame_header_flag = 255;
                this.frame_len = 0;
                this.frame_rbuff = new byte[size];
                this.frame_size = size;
            }

            public void Clear_Fream()
            {
                frame_header_flag = 255;
                frame_len = 0;
                Array.Clear(frame_rbuff, 0, frame_size);
            }

            public void Find_Frame_Header(byte data_in)
            {
                if (head[0] <= 2)
                {
                    if (data_in == (frame_rbuff[frame_header_flag + 1]))
                    {
                        frame_rbuff[frame_len++] = data_in;
                        frame_header_flag++;
                        return;
                    }
                }
                else
                {
                }
                Clear_Fream();
            }

            public byte Find_Frame_tail()
            {
                if (tail[0] == 1)
                {
                    if (frame_rbuff[frame_len - 1] == tail[1])
                    {
                        return 0;
                    }
                }
                else if (tail[0] == 2)
                {
                    if (frame_len > 2)
                    {
                        if ((frame_rbuff[frame_len - 2] == tail[1]) && (frame_rbuff[frame_len - 1] == tail[2]))
                        {
                            return 0;
                        }
                    }
                }
                else
                {
                    return 1;
                }
                return 2;
            }

            //数据转义
            public int Div_Data_Escape(byte[] pin, byte[] pout, int len)
            {
                int i = 0;
                int temp_len = 0;

                for (i = 0; i < len; i++)
                {
                    if ((i == 0) || (i == len - 1))
                    {
                        pout[temp_len++] = pin[i];
                    }
                    else
                    {
                        if ((pin[i] == 0x3A) || (pin[i] == 0x0D) || (pin[i] == 0x0A))//可替换帧头帧尾 插入数据
                        {
                            pout[temp_len++] = 0x55;
                            pout[temp_len++] = (byte)(pin[i] - (byte)0x05);
                        }
                        else
                        {
                            pout[temp_len++] = pin[i];
                        }
                    }
                }
                return temp_len;
            }

            //数据反转义
            public int Div_Data_UnEscape(byte[] pin, byte[] pout, int len)
            {
                int i = 0;
                int temp_len = 0;

                for (i = 0; i < len; i++)
                {
                    if (pin[i] == 0x55)//可替换帧头帧尾 插入数据
                    {
                        i = i + 1;
                        pout[temp_len++] = ((byte)((pin[i]) + 0x05));
                    }
                    else
                    {
                        pout[temp_len++] = pin[i];
                    }
                }
                return temp_len;
            }

        }
        /*********************************************************************************************************结束*********MATH*/

        /***********************************************************************************************************************CRC*/

        public class cal_check_list
        {
            //构造函数
            public cal_check_list()
            {

            }

            /* CRC 高位字节值表 */
            byte[] auchCRCHi = new byte[256]{
                0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
                0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
                0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
                0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
                0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
                0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
                0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
                0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
                0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
                0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40,
                0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
                0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
                0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
                0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40,
                0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
                0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
                0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
                0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
                0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
                0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
                0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
                0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40,
                0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
                0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
                0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
                0x80, 0x41, 0x00, 0xC1, 0x81, 0x40
        };

            /* CRC低位字节值表*/
            byte[] auchCRCLo = new byte[256]{
                0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06,
                0x07, 0xC7, 0x05, 0xC5, 0xC4, 0x04, 0xCC, 0x0C, 0x0D, 0xCD,
                0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09,
                0x08, 0xC8, 0xD8, 0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A,
                0x1E, 0xDE, 0xDF, 0x1F, 0xDD, 0x1D, 0x1C, 0xDC, 0x14, 0xD4,
                0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3,
                0x11, 0xD1, 0xD0, 0x10, 0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3,
                0xF2, 0x32, 0x36, 0xF6, 0xF7, 0x37, 0xF5, 0x35, 0x34, 0xF4,
                0x3C, 0xFC, 0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A,
                0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38, 0x28, 0xE8, 0xE9, 0x29,
                0xEB, 0x2B, 0x2A, 0xEA, 0xEE, 0x2E, 0x2F, 0xEF, 0x2D, 0xED,
                0xEC, 0x2C, 0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26,
                0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 0xA0, 0x60,
                0x61, 0xA1, 0x63, 0xA3, 0xA2, 0x62, 0x66, 0xA6, 0xA7, 0x67,
                0xA5, 0x65, 0x64, 0xA4, 0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F,
                0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68,
                0x78, 0xB8, 0xB9, 0x79, 0xBB, 0x7B, 0x7A, 0xBA, 0xBE, 0x7E,
                0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 0xB4, 0x74, 0x75, 0xB5,
                0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71,
                0x70, 0xB0, 0x50, 0x90, 0x91, 0x51, 0x93, 0x53, 0x52, 0x92,
                0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54, 0x9C, 0x5C,
                0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B,
                0x99, 0x59, 0x58, 0x98, 0x88, 0x48, 0x49, 0x89, 0x4B, 0x8B,
                0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,
                0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42,
                0x43, 0x83, 0x41, 0x81, 0x80, 0x40
        };
            //CRC16
            public int CAL_CRC16(byte[] puchMsg, int usDataLen)
            {
                byte uchCRCHi = 0xFF;                           // 高CRC字节初始化
                byte uchCRCLo = 0xFF;                           // 低CRC 字节初始化
                long uIndex; 		                             // CRC循环中的索引

                for (long i = 0; i < usDataLen; i++)
                {
                    uIndex = uchCRCHi ^ puchMsg[i]; 	    // 计算CRC
                    uchCRCHi = (byte)(uchCRCLo ^ auchCRCHi[uIndex]);
                    uchCRCLo = (byte)auchCRCLo[uIndex];
                }

                return (uchCRCHi << 8 | uchCRCLo);
            }

            //LQR
            public byte CAL_LQR(byte[] paddr, int cnt)
            {
                int i = 0;
                byte sum = 0;

                for (i = 1; i < cnt; i++)
                {
                    sum += paddr[i];
                }

                sum = (byte)((~sum) + 1);

                return (sum);
            }

        }

        //异或校验
        private byte CAL_XOR(byte[] pdat, int len)
        {
            int i = 0;
            byte sum = 0;

            for (i = 0; i < len; i++)
            {
                sum ^= pdat[i];
            }
            return (byte)sum;
        }

        /*************************************************************************************************************结束*******CRC*/

        //textbox控件输入 正则表达式 自动去空等非法检测################################################################################开始

        public class match_textbox_list
        {
            //构造函数
            public match_textbox_list()
            {

            }

            string pattern = @"^[0-9]*$";

            public string Match_TextBox_num09_ONE(string str_in)
            {
                string str = " ";
                string str_out = " ";

                str = str_in.Trim();//自动去空

                if (str.Contains(" "))
                {
                    str = str.Replace(" ", "");
                }

                Match m = Regex.Match(str, pattern);//匹配正则表达式 

                if (!m.Success)//输入的不是数字
                {
                    MessageBox.Show("输入数据非法！0-9之间的数据允许输入", "数据输入非法提示");
                }
                else //输入的是数字
                {
                    str_out = str;
                }

                return str_out;
            }

            public string[] Match_TextBox_num09_TWO(string[] str_in, int cnt)
            {
                string[] str = new string[128];
                string[] str_out = new string[128];

                for (int i = 0; i < cnt; i++)
                {
                    str[i] = str_in[i].Trim();      //自动去空

                    if (str[i].Contains(" "))
                    {
                        str[i] = str[i].Replace(" ", "");
                    }

                    Match m = Regex.Match(str[i], pattern);//匹配正则表达式 

                    if (!m.Success)//输入的不是数字
                    {
                        MessageBox.Show("要修改数据非法！请输入0-9之间的数据", "数据输入非法提示");
                    }
                    else //输入的是数字
                    {
                        str_out[i] = str[i];
                    }
                }
                return str_out;
            }
        }

        //textbox控件输入 正则表达式 自动去空等非法检测################################################################################结束

        /*##############################################################################################################自己写的类结束*/

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }
    }
}
